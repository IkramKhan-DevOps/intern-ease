from django.apps import AppConfig


class WebsiteConfig(AppConfig):
    name = 'src.website'
    verbose_name = 'Website'
